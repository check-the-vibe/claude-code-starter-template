<!-- This file gives specific information about the environment that Claude is running in -->

# Environment Information

## System Details
- **Operating System**: Darwin
- **Current Directory**: /Users/neal/Projects/claude-code-starter-template
- **User**: neal
- **Date Initialized**: 2025-06-29 22:33:33

## Project Context
- **Git Repository**: Yes
- **Platform**: Local Development Environment

## Available Tools
- Shell/Bash scripting
- File system access (read/write)
- Git operations
- Web fetch capabilities
- Code execution

## Constraints
_Add any specific constraints or limitations here_

## Notes
_Add any environment-specific notes or configurations_
