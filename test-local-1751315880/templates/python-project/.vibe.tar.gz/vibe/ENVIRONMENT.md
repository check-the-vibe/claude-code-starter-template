<!-- Python development environment information -->

# Python Environment Information

## System Details
- **Operating System**: [Will be updated on setup]
- **Current Directory**: [Will be updated on setup]
- **User**: [Will be updated on setup]
- **Date Initialized**: [Will be updated on setup]

## Python Environment
- **Python Version**: 3.8+ recommended
- **Virtual Environment**: Required (venv, virtualenv, or poetry)
- **Package Manager**: pip or poetry

## Project Context
- **Git Repository**: [Will be updated on setup]
- **Platform**: Python Development Environment

## Available Tools
- Python interpreter
- pip/poetry for package management
- pytest for testing
- black/ruff for formatting
- mypy for type checking
- Git operations
- Virtual environment management

## Python-Specific Setup
```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
pip install -r requirements-dev.txt

# Run tests
pytest

# Format code
black .

# Type check
mypy .
```

## Constraints
- Always use virtual environments
- Follow PEP 8 style guide
- Maintain >80% test coverage
- Use type hints for public APIs

## Notes
_Add project-specific Python configuration notes here_